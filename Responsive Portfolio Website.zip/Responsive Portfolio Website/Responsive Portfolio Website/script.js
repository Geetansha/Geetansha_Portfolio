function submitForm(){
    if(document.getElementsByClassName("nameInput").value=="" ||
        document.getElementsByClassName("commentsInput").value=="" ||
        document.getElementsByClassName("ageInput").value=="" ||
        document.getElementsByClassName("emailInput").value=="") {

        }
    else{
        alert("Submitted Successfully Thanks!!");
    }
}